# Working Dial Pad

A Pen created on CodePen.io. Original URL: [https://codepen.io/azizurrahman/pen/YGKgMo](https://codepen.io/azizurrahman/pen/YGKgMo).

Working Dial Pad that outputs the keys pressed. The backspace key deletes a character.